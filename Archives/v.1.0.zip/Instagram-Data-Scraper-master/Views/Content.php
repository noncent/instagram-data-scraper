<div class="tab-content">
	<div class="tab-pane active" id="inbox">
		<div class="container-fluid">
			<div class="content-container clearfix">
				<div class="col-md-12">
					<?php require_once View_Path . 'Form.php';?>
					<?php require_once View_Path . 'Table.php';?>
				</div>
			</div>
		</div>
	</div>
</div>
