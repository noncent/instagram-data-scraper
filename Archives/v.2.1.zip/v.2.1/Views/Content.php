<div class="tab-content">
	<div class="tab-pane active" id="inbox">
		<div class="container-fluid">
			<div class="content-container clearfix">
				<div class="col-md-12">
					<?php require_once VIEW_PATH . 'Form.php';?>
					<?php require_once VIEW_PATH . 'Table.php';?>
				</div>
			</div>
		</div>
	</div>
</div>
